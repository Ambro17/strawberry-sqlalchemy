"""A helper library to integrate sqlalchemy models with strawberry-graphql"""

__version__ = "0.1.4"
